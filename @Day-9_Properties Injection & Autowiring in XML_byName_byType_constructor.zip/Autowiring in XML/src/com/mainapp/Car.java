package com.mainapp;

public class Car {

    private int CarNo;
    private String carName;

    public Car() {
    }

    public Car(int carNo, String carName) {
        CarNo = carNo;
        this.carName = carName;
    }

    public int getCarNo() {
        return CarNo;
    }

    public void setCarNo(int carNo) {
        CarNo = carNo;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    @Override
    public String toString() {
        return "Car{" +
                "CarNo=" + CarNo +
                ", carName='" + carName + '\'' +
                '}';
    }
}
