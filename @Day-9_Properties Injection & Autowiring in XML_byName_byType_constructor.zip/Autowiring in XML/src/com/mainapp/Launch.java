package com.mainapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee = (Employee) context.getBean("employee");
        System.out.println(employee);

        Employee2 employee2 = (Employee2) context.getBean("employee2");
        System.out.println(employee2);

        context.close();
    }
}
