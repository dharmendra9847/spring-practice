package com.mainapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee {

    @Autowired                       // FIELD INJECTION
    private Account account;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED ZPC");
    }

    //@Autowired                    // CONSTRUCTOR INJECTION
//    public Employee(Account account) {
//        System.out.println("EMPLOYEE BEAN INSTANTIATED PC");
//        this.account = account;
//    }

//    public Account getAccount() {
//        return  account;
//    }

    //@Autowired                   // SETTER INJECTION
//    public void setAccount(Account account) {
//        System.out.println("EMPLOYEE SETTER CALLED: ACCOUNT");
//        this.account = account;
//    }

    @Override
    public String toString() {
        return "Employee{" +
                "account=" + account +
                '}';
    }
}
