package com.mainapp.config;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages = {"com.mainapp"})
@PropertySource("classpath:config.properties")
public class MyConfig {

}
