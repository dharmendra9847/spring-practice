package com.mainapp;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {

    //@Value("1002")
    private int eid;

    //@Value("Raju")
    private String ename;

    //@Value("${db.url}")
    private String url;

    public Employee() {
        System.out.println("Employee constructor");
    }

//    @Autowired
//    public Employee(@Value("1002")int eid, @Value("Raju")String ename, @Value("${db.url}")String url) { // CONSTRUCTION INJECTION
//        System.out.println("Employee parameterized constructor");
//        this.eid = eid;
//        this.ename = ename;
//        this.url = url;
//    }

    public int getEid() {
        return eid;
    }

    @Value("1002")                              // SETTER INJECTION
    public void setEid(int eid) {
        System.out.println("Employee set EID");
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    @Value("Raju")                              // SETTER INJECTION
    public void setEname(String ename) {
        System.out.println("Employee set ename");
        this.ename = ename;
    }

    public String getUrl() {
        return url;
    }

    @Value("${db.url}")                         // SETTER INJECTION
    public void setUrl(String url) {
        System.out.println("Employee set url");
        this.url = url;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", ename='" + ename + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
