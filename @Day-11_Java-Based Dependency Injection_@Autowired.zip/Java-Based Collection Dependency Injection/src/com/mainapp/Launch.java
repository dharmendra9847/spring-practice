package com.mainapp;

import com.mainapp.config.MyConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Launch {

    static void main(String[] args) {

        AnnotationConfigApplicationContext ca = new AnnotationConfigApplicationContext(MyConfig.class);
        Employee employee = ca.getBean(Employee.class);
        System.out.println(employee);
    }
}
