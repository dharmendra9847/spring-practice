package com.mainapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Employee {

    @Autowired                     // FIELD INJECTION
    private Account account;
    @Autowired
    //@Qualifier("list1")
    private List<String> listOfBooks;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED ZPC");
    }

    //@Autowired                    // CONSTRUCTOR INJECTION
    public Employee(Account account, List<String> listOfBooks) {
        System.out.println("EMPLOYEE BEAN INSTANTIATED PC");
        this.account = account;
        this.listOfBooks = listOfBooks;
    }

    //@Autowired                   // SETTER INJECTION
    public void setListOfBooks(List<String> listOfBooks) {
        this.listOfBooks = listOfBooks;
    }

    //@Autowired                   // SETTER INJECTION
    public void setAccount(Account account) {
        System.out.println("EMPLOYEE SETTER CALLED: ACCOUNT");
        this.account = account;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "account=" + account +
                ", listOfBooks=" + listOfBooks +
                '}';
    }
}
