package com.mainapp;

import org.springframework.stereotype.Component;

@Component
public class Account {

    private int accNo = 121212;
    private String bankName = "SBI";

    public Account() {
        System.out.println("ACC BEAN INSTANTIATED ZPC");
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @Override
    public String toString() {
        return " Account { " +
                "accNo = " + accNo +
                ", bankName = " + bankName + '}';
    }
}
