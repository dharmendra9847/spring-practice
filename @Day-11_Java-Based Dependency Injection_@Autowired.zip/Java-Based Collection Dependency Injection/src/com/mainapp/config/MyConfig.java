package com.mainapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.Arrays;
import java.util.List;

@Configuration
@ComponentScan(basePackages = {"com.mainapp"})
public class MyConfig {

    @Bean("list1")
    public List<String> getList1(){
        return Arrays.asList("1","2","3");
    }

    @Bean("list2")
    @Primary
    public List<String> getList2(){
        return Arrays.asList("10","20","30");
    }

    @Bean("list3")
    public List<String> getList3(){
        return Arrays.asList("100","200","300");
    }
}
