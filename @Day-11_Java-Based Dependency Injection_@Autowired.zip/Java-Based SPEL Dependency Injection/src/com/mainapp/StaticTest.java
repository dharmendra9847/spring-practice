package com.mainapp;

public class StaticTest {

    public static String doStaticTest(){
        return "StaticTest";
    }
}
