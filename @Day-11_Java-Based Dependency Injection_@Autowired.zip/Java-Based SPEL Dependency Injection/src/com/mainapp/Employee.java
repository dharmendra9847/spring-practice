package com.mainapp;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public class Employee {

    @Value("#{10 + 50}")
    private int eid;

    //@Value("#{'Raju'}")
    //@Value("#{test.doTest()}")
    //@Value("#{T(com.mainapp.StaticTest).doStaticTest()}")
    @Value("#{test.checkBalance() > 1000 ? 'Sufficient Balance' : 'Insufficient Balance'}")
    private String ename;


    @Value("#{ {'Book1', 'Book2', 'Book3'} }")
    private List<String> listOfBooks;

    @Value("#{ {'Book1', 'Book2', 'Book3'} }")
    private Set<String> setOfBooks;

    @Value("#{ {'Key1':'Book1', 'Key2':'Book2', 'Key3':'Book3'} }")
    private Map<String,String> mapOfBooks;

    @Value("#{ new String[]{'Book1', 'Book2', 'Book3'} }")
    private String[] arrayOfBooks;

    @Value("#{environment['db.url']}")
    private String url;

    public Employee() {
        System.out.println("Employee constructor"); 
    }

    public Employee(int eid, String ename, String url) {
        System.out.println("Employee parameterized constructor");
        this.eid = eid;
        this.ename = ename;
        this.url = url;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        System.out.println("Employee set EID");
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        System.out.println("Employee set ename");
        this.ename = ename;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        System.out.println("Employee set url");
        this.url = url;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", ename='" + ename + '\'' +
                ", listOfBooks=" + listOfBooks +
                ", setOfBooks=" + setOfBooks +
                ", mapOfBooks=" + mapOfBooks +
                ", arrayOfBooks=" + Arrays.toString(arrayOfBooks) +
                ", url='" + url + '\'' +
                '}';
    }
}
