package com.mainapp;

import java.util.Map;

public class Employee {

    private int eid;
    private String ename;
    private Map<String, String> mapOfBooks;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public Map<String, String> getMapOfBooks() {
        return mapOfBooks;
    }

    public void setMapOfBooks(Map<String, String> mapOfBooks) {
        this.mapOfBooks = mapOfBooks;
    }

    public void display() {
        System.out.println("Employee ID: " + eid);
        System.out.println("Employee Name: " + ename);
        //System.out.println("Employee Map of Books: " + mapOfBooks);
        for (Map.Entry<String, String> entry : mapOfBooks.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }


    @Override
    public String toString() {
        return "Id=" + eid + ", Name=" + ename + ", MapOfBooks=" + mapOfBooks;
    }
}
