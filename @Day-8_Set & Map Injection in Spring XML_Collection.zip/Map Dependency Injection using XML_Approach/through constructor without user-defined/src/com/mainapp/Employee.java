package com.mainapp;

import java.util.Map;

public class Employee {

    private int eid;
    private String ename;
    private Map<String, String> mapOfBooks;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public Employee(int eid, String ename, Map<String, String> mapOfBooks) {
        this.eid = eid;
        this.ename = ename;
        this.mapOfBooks = mapOfBooks;
    }

    public Map<String, String> getMapOfBooks() {
        return mapOfBooks;
    }

    public void display() {
        System.out.println("Employee ID: " + eid);
        System.out.println("Employee Name: " + ename);
        //System.out.println("Employee Map of Books: " + mapOfBooks);
        for (Map.Entry<String, String> entry : mapOfBooks.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }


    @Override
    public String toString() {
        return "Id=" + eid + ", Name=" + ename + ", MapOfBooks=" + mapOfBooks;
    }
}
