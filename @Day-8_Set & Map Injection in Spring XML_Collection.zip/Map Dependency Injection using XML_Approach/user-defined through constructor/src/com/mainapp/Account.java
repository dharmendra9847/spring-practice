package com.mainapp;

public class Account {

    private int accountId;
    private double balance;
    private String accountType;

    public Account(int accountId, double balance, String accountType) {
        this.accountId = accountId;
        this.balance = balance;
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "Account Id: " + accountId + ", Balance: " + balance + ", Account Type: " + accountType;
    }

}
