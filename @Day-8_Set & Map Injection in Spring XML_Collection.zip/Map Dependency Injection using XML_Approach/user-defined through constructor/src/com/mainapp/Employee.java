package com.mainapp;

import java.util.Map;

public class Employee {

    private int eid;
    private String ename;
    private Map<String, Account> mapOfAccounts;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public Map<String, Account> getMapOfAccounts() {
        return mapOfAccounts;
    }

    public Employee(int eid, String ename, Map<String, Account> mapOfAccounts) {
        this.eid = eid;
        this.ename = ename;
        this.mapOfAccounts = mapOfAccounts;
    }

    public void display() {
        System.out.println("Employee ID: " + eid);
        System.out.println("Employee Name: " + ename);
        //System.out.println("Employee Map of Books: " + mapOfBooks);
        for (Map.Entry<String, Account> entry : mapOfAccounts.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

}
