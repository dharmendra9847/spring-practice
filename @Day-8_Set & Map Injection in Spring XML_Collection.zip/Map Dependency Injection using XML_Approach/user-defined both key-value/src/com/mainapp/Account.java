package com.mainapp;

public class Account {

    private int accNo;
    private String accType;

    public Account(){
        System.out.println("ACCOUNT BEAN INSTANTIATED");
    }

    public Account(int accNo, String accType) {
        this.accNo = accNo;
        this.accType = accType;
    }

    @Override
    public String toString() {
        return " Account No: " + accNo + ", Account Type: " + accType;
    }
}
