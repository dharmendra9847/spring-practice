package com.mainapp;

import java.util.Map;

public class Employee {

    private int eid;
    private String ename;
    private Map<Student, Account> map;

    public Employee(){
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public Employee(int eid, String ename, Map<Student, Account> map) {
        this.eid = eid;
        this.ename = ename;
        this.map = map;
    }

    public Map<Student, Account> getMap() {
        return map;
    }

    public void display() {
        System.out.println("Employee Id: " + eid);
        System.out.println("Employee Name: " + ename);
        for (Map.Entry<Student, Account> entry : map.entrySet()) {
            Student student = entry.getKey();
            Account account = entry.getValue();
            System.out.println(student + " -> " + account);
        }
    }

    @Override
    public String toString() {
        return "ID: " + eid + ", Name: " + ename + ", Map: " + map + " ";
    }
}
