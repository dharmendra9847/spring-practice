package com.mainapp;

public class Student {

    private String stdname;
    private int rollNo;

    public Student(){
        System.out.println("STUDENT BEAN INSTANTIATED");
    }

    public Student(String stdname, int rollNo) {
        this.stdname = stdname;
        this.rollNo = rollNo;
    }

    @Override
    public String toString() {
        return "Student Name: " + stdname + " Roll No: " + rollNo +" ";
    }
}
