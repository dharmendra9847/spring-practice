package com.mainapp;

import java.util.Map;

public class Employee {

    private int eid;
    private String ename;
    private Map<String, Account> mapOfAccounts;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public Map<String, Account> getMapOfAccounts() {
        return mapOfAccounts;
    }

    public void setMapOfAccounts(Map<String, Account> mapOfAccounts) {
        this.mapOfAccounts = mapOfAccounts;
    }

    public void display() {
        System.out.println("Employee ID: " + eid);
        System.out.println("Employee Name: " + ename);
        //System.out.println("Employee Map of Books: " + mapOfBooks);
        for (Map.Entry<String, Account> entry : mapOfAccounts.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }


    @Override
    public String toString() {
        return "Id=" + eid + ", Name=" + ename + ", MapOfAccounts=" + mapOfAccounts;
    }
}
