package com.setinjectionusingsetter;

import java.util.Set;

public class Employee {

    private int eid;
    private String ename;
    private Set<String> setOfBooks;

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public Set<String> getSetOfBooks() {
        return setOfBooks;
    }

    public void setSetOfBooks(Set<String> setOfBooks) {
        this.setOfBooks = setOfBooks;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", ename='" + ename + '\'' +
                ", setOfBooks=" + setOfBooks +
                '}';
    }

    public void display() {
        System.out.println("ID: " + eid);
        System.out.println("Name: " + ename);
        System.out.println("Set Of Books: " + setOfBooks);
    }
}
