package com.setinjectionusingsetter;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee = (Employee) context.getBean("employee");
        System.out.println(employee.getSetOfBooks().getClass());
        System.out.println(employee);
        System.out.println(employee.getSetOfBooks().size());
        employee.display();
    }
}
