package com.mainapp;

import java.util.Set;

public class Employee {

    private int eid;
    private String ename;
    private Set<Account> accountSet;

    public Employee() {
        System.out.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public Employee(int eid, String ename, Set<Account> accountSet) {
        this.eid = eid;
        this.ename = ename;
        this.accountSet = accountSet;
    }

    public Set<Account> getAccountSet() {
        return accountSet;
    }

    public void display(){
        System.out.println("Id: "+eid);
        System.out.println("Name: "+ename);

        for (Account account : accountSet) {
            System.out.println(account);
        }
    }
}
