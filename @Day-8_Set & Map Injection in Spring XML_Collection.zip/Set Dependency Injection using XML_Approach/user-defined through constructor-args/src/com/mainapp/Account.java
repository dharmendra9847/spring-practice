package com.mainapp;

public class Account implements Comparable<Account>{

    private int accountNumber;
    private String accountType;

    public Account() {
        System.out.println("ACCOUNT BEAN INSTANTIATED");
    }

    public Account(int accountNumber, String accountType) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
    }

    @Override
    public int compareTo(Account o) {
        return this.accountNumber - o.accountNumber; // sorting logic
    }

    @Override
    public String toString() {
        return  "Account:"  + accountNumber + ", Account Type:" + accountType;
    }

}
