package com.mainapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee1 = (Employee) context.getBean("employee1");
        System.out.println(employee1.getAccountSet().getClass());

        employee1.display();

//        Employee employee2 = (Employee) context.getBean("employee2");
//        System.out.println(employee2.getAccountSet().getClass());
//
//        employee2.display();
    }
}
