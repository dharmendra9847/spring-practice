package com.mainapp;

import com.mainapp.config.MyConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Launch {

    static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
        CrudOperation bean = (CrudOperation) context.getBean("crud");
        //bean.insert(2,"Kaju", "Add-2", 6000);
        //bean.update(4, "Raju");
        //bean.delete(4);
        //bean.readAll();
        //bean.readAllPojoBased();
        bean.readCriteriaBased(5);
    }
}
