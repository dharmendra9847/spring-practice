package com.mainapp.config;

import com.mainapp.CrudOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
@ComponentScan(basePackages = {"com.mainapp"})
@PropertySource("classpath:config.properties")
public class MyConfig {

    @Autowired
    private Environment environment;

    @Bean
    public DataSource  dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(environment.getProperty("db_driver"));
        dataSource.setUrl(environment.getProperty("db_url"));
        dataSource.setUsername(environment.getProperty("db_username"));
        dataSource.setPassword(environment.getProperty("db_password"));
        return dataSource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate() {
        return new JdbcTemplate(dataSource());
    }

    @Bean("crud")
    public CrudOperation  crudOperation() {
        CrudOperation crudOperation = new CrudOperation();
        crudOperation.setJdbcTemplate(jdbcTemplate());
        return crudOperation;
    }
}
