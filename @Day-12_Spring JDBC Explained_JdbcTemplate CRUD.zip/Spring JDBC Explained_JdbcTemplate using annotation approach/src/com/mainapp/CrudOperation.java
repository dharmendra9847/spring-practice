package com.mainapp;

import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

public class CrudOperation {

    private JdbcTemplate  jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insert(int eid, String ename, String eaddress, int esalary) {
//        String sql = "insert into employee(eid, ename, eaddress, esalary) values(?,?,?,?)";
//        jdbcTemplate.update(sql, eid, ename, eaddress, esalary);

        String sql = "insert into employee values (?,?,?,?)";
        int row = jdbcTemplate.update(sql, eid, ename, eaddress, esalary);
        System.out.println(row);
    }

    public void update(int eid, String ename) {

        String sql = "update employee set ename = ? where eid = ?";
        int row = jdbcTemplate.update(sql, ename, eid);
        System.out.println(row);
    }

    public void delete(int eid) {

        String sql = "delete from employee where eid = ?";
        int row = jdbcTemplate.update(sql, eid);
        System.out.println(row);
    }

    public void readAll(){
        String sql = "select * from employee";
        List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(sql);
        //System.out.println(queryForList);
        for (Map<String, Object> map : queryForList) {
            System.out.println(map);
        }

//        for (Map<String, Object> map : queryForList) {
//            for (String key : map.keySet()) {
//                Object value = map.get(key);
//                System.out.println(key + ":" + value);
//            }
//        }

//        for (Map<String, Object> map : queryForList) {
//            for (Map.Entry<String, Object> entry : map.entrySet()){
//                System.out.println(entry.getKey() + ":" + entry.getValue());
//            }
//              System.out.println();
//        }
    }

    public void readAllPojoBased() {
        String sql = "select * from employee";
        List<Employee> list = jdbcTemplate.query(sql, new RowMapperImpl());
        for (Employee employee : list) {
            System.out.println(employee);
        }
    }

    public void readCriteriaBased(int eid) {
        String sql = "select * from employee where eid = ?";
        Employee employee = jdbcTemplate.queryForObject(sql, new RowMapperImpl(), eid);
        System.out.println(employee);
    }
}
