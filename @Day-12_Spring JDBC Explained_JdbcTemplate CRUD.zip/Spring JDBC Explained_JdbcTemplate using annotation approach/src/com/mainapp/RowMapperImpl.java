package com.mainapp;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RowMapperImpl implements RowMapper<Employee> {

    @Override
    public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {

        Employee employee = new Employee();
        employee.setEid(rs.getInt("eid"));
        employee.setEname(rs.getString("ename"));
        employee.setEaddress(rs.getString("eaddress"));
        employee.setEsalary(rs.getInt("esalary"));

        System.out.println("ROW MAPPED " + (rowNum+1));

        return employee;
    }
}
