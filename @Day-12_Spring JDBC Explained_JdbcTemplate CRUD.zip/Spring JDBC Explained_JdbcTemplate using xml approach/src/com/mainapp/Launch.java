package com.mainapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        CrudOperation bean = (CrudOperation) context.getBean("curd");
        //bean.insert(2,"Kaju", "Add-2", 6000);
        //bean.update(4, "Raju");
        //bean.delete(4);
        //bean.readAll();
        //bean.readAllPojoBased();
        bean.readCriteriaBased(2);
    }
}
