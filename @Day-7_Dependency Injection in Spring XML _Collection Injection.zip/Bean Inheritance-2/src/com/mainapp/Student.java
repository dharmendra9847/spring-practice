package com.mainapp;

public class Student {

    private String URL;
    private int CC;
    private int studentId;

    public Student() {
        System.out.println("Student bean instantiated");
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    @Override
    public String toString() {
        return "Student{" +
                "sURL='" + URL + '\'' +
                ", studentId=" + studentId +
                ", CC=" + CC +
                '}';
    }
}
