package com.mainapp;

public class Manager {

    private String URL;
    private int CC;
    private int managerId;

    public Manager() {
        System.out.println("Manager bean instantiated");
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "URL='" + URL + '\'' +
                ", managerId=" + managerId +
                ", CC=" + CC +
                '}';
    }
}
