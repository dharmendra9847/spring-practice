package com.mainapp;

public class Employee {

    private String URL;
    private int CC;
    private int employeeId;

    public Employee() {
        System.out.println("Employee bean instantiated");
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "URL='" + URL + '\'' +
                ", employeeId=" + employeeId +
                ", CC=" + CC +
                '}';
    }
}
