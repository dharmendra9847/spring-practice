package com.mainapp;

public class Student {

    private String url;
    private  String countryCode;
    private int roll;

    public Student() {
        IO.println("STUDENT BEAN INSTANTIATED!");
    }

    public Student(String url, String countryCode, int roll) {
        this.url = url;
        this.countryCode = countryCode;
        this.roll = roll;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    @Override
    public String toString() {
        return "Student{" +
                "url='" + url + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", roll=" + roll +
                '}';
    }
}
