package com.mainapp;

public class Employee {

    private String url;
    private  String countryCode;
    private int eid;

    public Employee() {
        IO.println("EMPLOYEE BEAN INSTANTIATED");
    }

    public Employee(String url, String countryCode, int eid) {
        this.url = url;
        this.countryCode = countryCode;
        this.eid = eid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "url='" + url + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", eid=" + eid +
                '}';
    }
}
