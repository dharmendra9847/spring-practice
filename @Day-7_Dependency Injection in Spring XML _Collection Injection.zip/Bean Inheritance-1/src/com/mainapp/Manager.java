package com.mainapp;

public class Manager {

    private String url;
    private  String countryCode;
    private int mid;

    public Manager() {
        IO.println("MANAGER BEAN INSTANTIATED!");
    }

    public Manager(String url, String countryCode, int mid) {
        this.url = url;
        this.countryCode = countryCode;
        this.mid = mid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "url='" + url + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", mid=" + mid +
                '}';
    }
}
