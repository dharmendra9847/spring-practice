package com.mainapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main() {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee = (Employee) context.getBean("employee");
        IO.println(employee);

        Manager manager = (Manager) context.getBean("manager");
        IO.println(manager);

        Student student = (Student) context.getBean("student");
        IO.println(student);


        context.close();
    }
}
