package com.accountlistinjection;

import java.util.List;

public class Employee {

    private int eid;
    private String ename;
    private List<Account> listOfAccounts;

    // Setter for eid
    public void setEid(int eid) {
        this.eid = eid;
    }

    // Setter for ename
    public void setEname(String ename) {
        this.ename = ename;
    }

    // IMPORTANT Setter for List
    public void setListOfAccounts(List<Account> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }

    public void display() {
        System.out.println("ID: " + eid);
        System.out.println("Name: " + ename);
        for (Account acc : listOfAccounts) {
            System.out.println(acc);
        }
    }


//    @Override
//    public String toString() {
//        return "Employee{" +
//                "eid=" + eid +
//                ", ename='" + ename + '\'' +
//                ", listOfAccounts=" + listOfAccounts +
//                '}';
//    }
}
