package com.accountlistinjection;

public class Account {

    private int accNo;
    private String accType;

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    @Override
    public String toString() {
        return "Account No: " + accNo + ", Type: " + accType;
    }


//    @Override
//    public String toString() {
//        return "Account{" +
//                "accNo=" + accNo +
//                ", accType='" + accType + '\'' +
//                '}';
//    }
}
