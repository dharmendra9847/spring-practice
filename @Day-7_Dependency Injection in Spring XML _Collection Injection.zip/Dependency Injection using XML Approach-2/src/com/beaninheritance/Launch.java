package com.beaninheritance;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

//        bean inheritance
//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//
//        Employee emp = (Employee) context.getBean("emp");
//        Manager mgr = (Manager) context.getBean("mgr");
//        Student std = (Student) context.getBean("std");
//
//        System.out.println(emp);
//        System.out.println(mgr);
//        System.out.println(std);
//
//        context.close();


        //Dependency Injection using XML Approach-2

    }
}
