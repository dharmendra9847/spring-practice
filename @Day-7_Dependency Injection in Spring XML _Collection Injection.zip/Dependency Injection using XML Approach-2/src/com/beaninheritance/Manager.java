package com.beaninheritance;

public class Manager {

    private String url;
    private int countryCode;
    private int managerId;

    public Manager() {
        System.out.println("Manager bean instantiated");
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setCountryCode(int countryCode) {
        this.countryCode = countryCode;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "url='" + url + '\'' +
                ", countryCode=" + countryCode +
                ", managerId=" + managerId +
                '}';
    }
}
