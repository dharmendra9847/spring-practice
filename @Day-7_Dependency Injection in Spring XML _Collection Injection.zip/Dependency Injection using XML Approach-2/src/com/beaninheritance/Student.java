package com.beaninheritance;

public class Student {

    private String url;
    private int countryCode;
    private int studentId;

    public Student() {
        System.out.println("Student bean instantiated");
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setCountryCode(int countryCode) {
        this.countryCode = countryCode;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return "Student{" +
                "url='" + url + '\'' +
                ", countryCode=" + countryCode +
                ", studentId=" + studentId +
                '}';
    }
}
