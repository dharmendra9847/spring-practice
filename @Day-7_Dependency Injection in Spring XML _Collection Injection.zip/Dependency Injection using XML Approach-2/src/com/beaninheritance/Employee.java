package com.beaninheritance;

public class Employee {

    private String url;
    private int countryCode;
    private int employeeId;

    public Employee() {
        System.out.println("Employee bean instantiated");
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setCountryCode(int countryCode) {
        this.countryCode = countryCode;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "url='" + url + '\'' +
                ", countryCode=" + countryCode +
                ", employeeId=" + employeeId +
                '}';
    }
}
