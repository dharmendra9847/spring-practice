package com.mainapp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main() {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee = (Employee) context.getBean("employee");
        IO.println(employee);

        IO.println(employee.getClass());
        IO.println(employee.getListOfAccounts().getClass());
        IO.println(employee.getListOfAccounts());
        IO.println(employee.getListOfAccounts().getFirst());

        context.close();
    }
}
