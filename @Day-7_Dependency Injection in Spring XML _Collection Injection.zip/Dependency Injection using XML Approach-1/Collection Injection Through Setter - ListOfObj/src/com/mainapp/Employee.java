package com.mainapp;

import java.util.List;

public class Employee {

    private int eid;
    private String eName;
    private List<Account> listOfAccounts;

    public Employee() {
        IO.println("EMPLOYEE BEAN INSTANTIATION");
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public List<Account> getListOfAccounts() {
        return listOfAccounts;
    }

    public void setListOfAccounts(List<Account> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", eName='" + eName + '\'' +
                ", listOfAccounts=" + listOfAccounts +
                '}';
    }
}
