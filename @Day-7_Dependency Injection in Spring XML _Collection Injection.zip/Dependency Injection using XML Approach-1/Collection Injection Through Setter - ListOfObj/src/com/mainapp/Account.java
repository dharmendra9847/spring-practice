package com.mainapp;

import java.util.List;

public class Account {

    private int eid;
    private String eName;
    private List<String> listOfAccounts;

    public Account() {
        IO.println("ACCOUNT BEAN INSTANTIATION");
    }

    public Account(int eid, String eName, List<String> listOfAccounts) {
        this.eid = eid;
        this.eName = eName;
        this.listOfAccounts = listOfAccounts;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public List<String> getListOfAccounts() {
        return listOfAccounts;
    }

    public void setListOfAccounts(List<String> listOfAccounts) {
        this.listOfAccounts = listOfAccounts;
    }

    @Override
    public String toString() {
        return "Account{" +
                "eid=" + eid +
                ", eName='" + eName + '\'' +
                ", listOfAccounts=" + listOfAccounts +
                '}';
    }
}
