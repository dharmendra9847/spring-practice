package com.mainapp;

import java.util.List;

public class Employee {

    private int eid;
    private String eName;
    private List<String> listOfBooks;

    public Employee() {
        IO.println("EMPLOYEE BEAN INSTANTIATION");
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public List<String> getListOfBooks() {
        return listOfBooks;
    }

    public void setListOfBooks(List<String> listOfBooks) {
        this.listOfBooks = listOfBooks;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", eName='" + eName + '\'' +
                ", listOfBooks=" + listOfBooks +
                '}';
    }
}
