package com.simple;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Employee employee = (Employee) context.getBean("employee");
        employee.display();
    }
}
