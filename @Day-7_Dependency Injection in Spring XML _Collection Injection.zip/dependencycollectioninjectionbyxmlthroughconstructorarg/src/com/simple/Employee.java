package com.simple;

import com.userdefineaccountlist.Account;

import java.util.List;

public class Employee {

    private int eid;
    private String ename;
    private List<String> listOfAcc;

    public Employee(int eid, String ename, List<String> listOfAcc) {
        this.eid = eid;
        this.ename = ename;
        this.listOfAcc = listOfAcc;
    }

    public void display() {
        System.out.println("ID: " + eid);
        System.out.println("Name: " + ename);
        System.out.println("AccountList: " + listOfAcc);
    }
}
