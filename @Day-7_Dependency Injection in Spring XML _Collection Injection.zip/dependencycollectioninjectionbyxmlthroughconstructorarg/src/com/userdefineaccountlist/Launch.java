package com.userdefineaccountlist;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launch {

    static void main(String[] args) {

//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//        Employee employee = (Employee) context.getBean("employee");
////        System.out.println(employee);
//        employee.display();
    }
}
