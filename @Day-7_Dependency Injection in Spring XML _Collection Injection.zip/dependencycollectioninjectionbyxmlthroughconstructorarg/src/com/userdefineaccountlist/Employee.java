package com.userdefineaccountlist;

import java.util.List;

public class Employee {

    private int eid;
    private String ename;
    private List<Account> accountList;

    public Employee(int eid, String ename, List<Account> accountList) {
        this.eid = eid;
        this.ename = ename;
        this.accountList = accountList;
    }

    public void display() {
        System.out.println("ID: " + eid);
        System.out.println("Name: " + ename);
        for (Account acc : accountList) {
            System.out.println(acc);
        }
    }

//    @Override
//    public String toString() {
//        return "Employee[" +
//                "eid=" + eid +
//                ", ename='" + ename + '\'' +
//                ", accountList=" + accountList +
//                ']';
//    }
}
