package com.userdefineaccountlist;

public class Account {

    private int accNo;
    private String accType;

    public Account(int accNo, String accType) {
        this.accNo = accNo;
        this.accType = accType;
    }

    @Override
    public String toString(){
        return "Account No: " + accNo + ", Type: " + accType;
    }

//    @Override
//    public String toString() {
//        return "Account[" +
//                "accNo=" + accNo +
//                ", accType='" + accType + '\'' +
//                ']';
//    }
}
